# Requirements
- Python 3.6+
- Required packages:
```bash
pandas
numpy
scikit-learn
nltk
```

# How to Run the Code

```bash
python br_classification.py
```
